<template>
  <div class="force-graph" ref="graphContainer"></div>
</template>

<script>
import * as d3 from 'd3'
import data from '../assets/miserables.json'

export default {
  name: 'ForceGraph',
  data() {
    return {
      simulation: null,
      svg: null,
      brush: null,
      selectedNodes: new Set()
    }
  },
  mounted() {
    this.initializeGraph()
  },
  methods: {
    initializeGraph() {
      const width = this.$refs.graphContainer.clientWidth
      const height = this.$refs.graphContainer.clientHeight

      this.svg = d3.select(this.$refs.graphContainer)
        .append('svg')
        .attr('width', width)
        .attr('height', height)

      const g = this.svg.append('g')

      // 创建力导向图模拟
      this.simulation = d3.forceSimulation(data.nodes)
        .force('link', d3.forceLink(data.links).id(d => d.id))
        .force('charge', d3.forceManyBody().strength(-50))
        .force('center', d3.forceCenter(width / 2, height / 2))

      // 绘制连接线
      const link = g.append('g')
        .selectAll('line')
        .data(data.links)
        .join('line')
        .attr('stroke', '#999')
        .attr('stroke-opacity', 0.6)
        .attr('stroke-width', d => Math.sqrt(d.value))

      // 绘制节点
      const node = g.append('g')
        .selectAll('circle')
        .data(data.nodes)
        .join('circle')
        .attr('r', 5)
        .attr('fill', d => d3.schemeCategory10[d.group])
        .call(this.drag(this.simulation))

      // 添加刷选功能
      this.brush = d3.brush()
        .extent([[0, 0], [width, height]])
        .on('end', this.brushended)

      this.svg.append('g')
        .attr('class', 'brush')
        .call(this.brush)

      // 更新力导向图
      this.simulation.on('tick', () => {
        link
          .attr('x1', d => d.source.x)
          .attr('y1', d => d.source.y)
          .attr('x2', d => d.target.x)
          .attr('y2', d => d.target.y)

        node
          .attr('cx', d => d.x)
          .attr('cy', d => d.y)
      })
    },
    drag(simulation) {
      function dragstarted(event) {
        if (!event.active) simulation.alphaTarget(0.3).restart()
        event.subject.fx = event.subject.x
        event.subject.fy = event.subject.y
      }

      function dragged(event) {
        event.subject.fx = event.x
        event.subject.fy = event.y
      }

      function dragended(event) {
        if (!event.active) simulation.alphaTarget(0)
        event.subject.fx = null
        event.subject.fy = null
      }

      return d3.drag()
        .on('start', dragstarted)
        .on('drag', dragged)
        .on('end', dragended)
    },
    brushended(event) {
      const selection = event.selection
      if (!selection) return

      // 获取选中的节点
      const selectedNodes = d3.selectAll('circle').filter(function() {
        const circle = d3.select(this)
        const cx = parseFloat(circle.attr('cx'))
        const cy = parseFloat(circle.attr('cy'))
        return cx >= selection[0][0] && 
               cx <= selection[1][0] && 
               cy >= selection[0][1] && 
               cy <= selection[1][1]
      }).data()

      this.$emit('nodesSelected', selectedNodes)
    }
  }
}
</script>

<style scoped>
.force-graph {
  width: 100%;
  height: 100%;
}
</style>