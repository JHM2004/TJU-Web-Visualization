<template>
  <div class="bar-chart" ref="chartContainer"></div>
</template>

<script>
import * as d3 from 'd3'

export default {
  name: 'BarChart',
  props: {
    selectedNodes: {
      type: Array,
      default: () => []
    }
  },
  watch: {
    selectedNodes: {
      handler() {
        this.updateChart()
      },
      deep: true
    }
  },
  data() {
    return {
      chartOptions: {
        responsive: true,
        plugins: {
          tooltip: {
            enabled: true,
            displayColors: false,
            callbacks: {
              label: function(context) {
                return `连接数量: ${context.raw}`
              }
            }
          },
          legend: {
            display: false
          }
        },
        scales: {
          y: {
            beginAtZero: true,
            title: {
              display: true,
              text: '连接数量'
            }
          }
        }
      }
    }
  },
  methods: {
    updateChart() {
      const container = this.$refs.chartContainer
      d3.select(container).selectAll('*').remove()

      if (this.selectedNodes.length === 0) return

      const width = container.clientWidth
      const height = container.clientHeight
      const margin = { top: 20, right: 20, bottom: 100, left: 60 }

      const svg = d3.select(container)
        .append('svg')
        .attr('width', width)
        .attr('height', height)

      const x = d3.scaleBand()
        .domain(this.selectedNodes.map(d => d.id))
        .range([margin.left, width - margin.right])
        .padding(0.1)

      const y = d3.scaleLinear()
        .domain([0, d3.max(this.selectedNodes, d => d.group)])
        .nice()
        .range([height - margin.bottom, margin.top])

      // 添加x轴
      svg.append('g')
        .attr('transform', `translate(0,${height - margin.bottom})`)
        .call(d3.axisBottom(x))
        .selectAll('text')
        .attr('transform', 'translate(-10,10) rotate(-45)')
        .style('text-anchor', 'end')
        .style('font-size', '12px')

      // 添加y轴
      svg.append('g')
        .attr('transform', `translate(${margin.left},0)`)
        .call(d3.axisLeft(y))
        .selectAll('text')
        .style('font-size', '12px')

      // 绘制柱状图
      svg.append('g')
        .selectAll('rect')
        .data(this.selectedNodes)
        .join('rect')
        .attr('x', d => x(d.id))
        .attr('y', d => y(d.group))
        .attr('height', d => y(0) - y(d.group))
        .attr('width', x.bandwidth())
        .attr('fill', d => d3.schemeCategory10[d.group])
        // 添加鼠标悬停效果
        .on('mouseover', function(event, d) {
          d3.select(this)
            .transition()
            .duration(200)
            .attr('opacity', 0.7)

          // 计算提示文本的位置
          const xPosition = x(d.id) + x.bandwidth() / 2
          let yPosition = y(d.group) - 15

          // 确保提示文本不会超出顶部边界
          if (yPosition < margin.top) {
            yPosition = y(d.group) + 30  // 如果超出顶部，则显示在柱子下方
          }

          // 添加提示框背景
          svg.append('rect')
            .attr('class', 'tooltip-bg')
            .attr('x', xPosition - 50)
            .attr('y', yPosition - 20)
            .attr('width', 100)
            .attr('height', 25)
            .attr('fill', 'white')
            .attr('stroke', '#ccc')
            .attr('rx', 5)
            .attr('ry', 5)

          // 添加提示文本
          svg.append('text')
            .attr('class', 'tooltip')
            .attr('x', xPosition)
            .attr('y', yPosition)
            .attr('text-anchor', 'middle')
            .attr('dominant-baseline', 'middle')
            .style('font-size', '12px')
            .text(`连接数量: ${d.group}`)
        })
        .on('mouseout', function() {
          d3.select(this)
            .transition()
            .duration(200)
            .attr('opacity', 1)
          
          // 移除提示框和背景
          svg.selectAll('.tooltip').remove()
          svg.selectAll('.tooltip-bg').remove()
        })
    }
  },
  mounted() {
    this.updateChart()
  }
}
</script>

<style scoped>
.bar-chart {
  width: 100%;
  height: 100%;
}
</style> 