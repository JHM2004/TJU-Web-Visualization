<template>
  <div id="app">
    <div class="container">
      <div class="left-panel">
        <bar-chart :selectedNodes="selectedNodes" />
      </div>
      <div class="right-panel">
        <force-graph @nodesSelected="handleNodesSelected" />
      </div>
    </div>
  </div>
</template>

<script>
import ForceGraph from './components/ForceGraph.vue'
import BarChart from './components/BarChart.vue'

export default {
  name: 'App',
  components: {
    ForceGraph,
    BarChart
  },
  data() {
    return {
      selectedNodes: []
    }
  },
  methods: {
    handleNodesSelected(nodes) {
      this.selectedNodes = nodes
    }
  }
}
</script>

<style>
#app {
  height: 100vh;
}

.container {
  display: flex;
  width: 100%;
  height: 100vh;
}

.left-panel {
  width: 40%;
  padding: 20px;
  border-right: 1px solid #ccc;
  overflow: auto;
  display: flex;
  flex-direction: column;
}

.right-panel {
  width: 60%;
  padding: 20px;
  overflow: auto;
}
</style> 